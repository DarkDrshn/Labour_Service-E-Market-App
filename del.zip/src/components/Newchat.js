import React from 'react';
import { ChatEngine } from 'react-chat-engine';

function Chat() {
	return (
        <>
		<ChatEngine
			projectID='57fe6492-fc09-4017-96f5-7f9f1cf1c487'
			userName='bmrock'
			userSecret='Abcdefg'
		/>
        </>
	);
}

export default Chat;