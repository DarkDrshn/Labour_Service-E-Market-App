import React from 'react'

function Emptyviews() {
  return (
    <div>Empty it is </div>
  )
}


export default Emptyviews
