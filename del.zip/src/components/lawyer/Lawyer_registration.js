//registration of lawyer

import React from 'react'

function LsRegister() {
  return (
    <div>LsRegister</div>
  )
}

export default LsRegister;