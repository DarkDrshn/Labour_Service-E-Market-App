import React from 'react'

function CliLogout() {
  return (
    <div>After Login, logout page</div>
  )
}

export default CliLogout