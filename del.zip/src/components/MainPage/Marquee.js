import React from 'react';



export function Marquee() {
  return (
    <div className="marquee-container overflow-hidden bg-gray-200">
    <div className="marquee ">
      <span className="inline-block ml-40">Register swiftly and secure your next assignment in just a few steps, Empowering you to excel and achieve your Best.</span>
    </div>
  </div>
  );
}