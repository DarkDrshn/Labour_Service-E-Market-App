import React from 'react'

function CliLogout() {
  return (
    <div>CliLogout</div>
  )
}

export default CliLogout