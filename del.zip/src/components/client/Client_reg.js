  
  function CliRegister() {
    return (
      <>
        Login Soon
      </>
    );
  }

export default CliRegister;